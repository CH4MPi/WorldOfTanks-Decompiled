# Python bytecode 2.7 (decompiled from Python 2.7)
# Embedded file name: scripts/client/festivity/dummy/df_requester.py
from festivity.base import BaseFestivityRequester

class DummyRequester(BaseFestivityRequester):
    dataKey = 'dummyFestivity'
