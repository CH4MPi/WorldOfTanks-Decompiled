# Python bytecode 2.7 (decompiled from Python 2.7)
# Embedded file name: scripts/client/festivity/dummy/df_processor.py
from festivity.base import BaseFestivityProcessor

class DummyCommandsProcessor(BaseFestivityProcessor):
    pass
